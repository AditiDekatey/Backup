<template>
    <div id="chat-main-wrapper">
     <!-- ALC Chat Info section -->

     <div v-if="!splash && showALCLevelInfo && chatHistory.length == 0" class="alc-container main-alc-container">
     <div class="flex space-between">
        <div style="display:flex;align-items:center;">
            < img src='../assets/chat_screen.png" style ="height:26px;width:26px;margin-right:9px;"/>
            <span class="boehringer-head" style="font-size:17px;font-weight:bold;" >
                The responses are at the  {{ isperson ? 'HCP' : 'HCO'}} level. 
            </span>
            </div>

            <img class='pointer' @click="closeALCLevelInfo" src="../assets/alc_info_close.png"
            style="width:12px;height:12px;"/>
      </div>

        <div style="font-size:17px;margin-top:9px;">
            For territory level, please proceed to the main 1Customer Assist page.
        </div>
    </div>

    <div v-if="splash" :class="['splashScreen', {'fade-out':!splash}]">
        <div class="logo-container">
            <img src="../assets/logo.png"> alt="logo" class="logo-img" id="logo">
            <div class="logo">
                <span class="one-customer"> 1 Customer </span> &nbsp;
                <span class="assist"> Assist </span>
            </div>
            <div class="underline"></div>
        </div>
    </div>
   
    
    <div v-else id="chat-container-wrapper">
        <div v-show="overlay" class="overlay"></div>
        {{ spinner }}
        < div v-if="loadingveevamessage" class="overlay"
        style="display:flex;justify-content:center;align-items:center;">
        <img src='../assets/spinner.svg" alt="Loading...'/>
    </div>

    <div :class="['chat-container',{'chat-history-open':historyOpen}]" style="flex:1;">
        <HistoryPanel :chatMessages="chatMessages" :historyOpen ="historyOpen" :loading="loading"
        @rename-session="renameSession" @toggle-history="toggleHistory" @HistoryPaneOpen="openHistoryPane"
        @load-session="loadSessionChats" @toggle-bookmark="bookmark" @delete-session="deleteSession"
        @start-new-chat="StartNewChat" @download-chats="downloadChatHistoryAsPDF" @load-trending-question="loadTrendingQuestion"
        @show-toast="showToast" />

        <div v-if="chatHistory.length ==0 && !showObservationHistoryTab" class="chat-screen">
           <div class="landing-page-container">
            <div class="suggestion" :style="{
                width: isHistoryOpen ? '82%' : '68%',display: 'flex',justifyContent: 'center',flexDirection: 'column' ,gap:'1rem'    
            }">
                <div v-if="!showALCLevelInfo" class="Bi-logo">
                    <img src="../assets/logo" 
                    style="height:30px;margin: 0 5px;"/>
                    1 Customer Assist
                </div>
                <div class="header" style="text-align: left;">
                    <h1 class="assistant-title">How can I help you today?</h1>
                </div>
                <div class="suggestion" style="width:90%;display: 'flex';justify-content:flex-start;">
                    <div class="suggestions-container">
                        <div style="display: flex;gap:1rem;">
                            <button v-for="(suggestion,index) in suggestions1" :key="index"
                            @click="copyToInput(suggestion)" class="suggestion-button">
                                {{ suggestion }}
                        </button>
                        </div>
                        <div :style="{display: flex,gap:'1rem',maxWidth: isHistoryOpen?'90%':'100%'}">
                              <button v-for="(suggestion,index) in suggestions2" :key="index"
                                @click="copyToInput(suggestion)" class="suggestion-button"
                                :style="{maxWidth:isHistoryOpen?'fit-content':'fit-content'}">
                                    {{ suggestion }}
                                </button>

                        </div>
                    </div>
                </div>
            </div>

            <div class="chat-input-area" style="position:absolute;">
                <div style="width:90%;position: relative;">
                    <div class="rec-spinner-speaker" v-if="isRecording || (!Recording && isRecording)">
                        <div class="rect1"></div>
                        <div class="rect2"></div>
                        <div class="rect3"></div>
                        <div class="rect4"></div>
                        <div class="rect5"></div>
                        <div class="rect6"></div>
                        <div class="rect7"></div>
                    </div>

                    <div class="promptbox">
                        <textarea ref="textarea" type="text" v-model="prompt"
                        v-on:keydown.enter="sendToMax($event)" :placeholder="getPlaceHolderText()"
                        class="chat-input"
                        :class="(Recording || isRecording) ? 'chat-input-listening':'chat-input'"
                        :disabled="Recording || isRecording || disabletext" maxlength="2000"
                        @input="resizeTextArea" id="input-message" />
                        <img src="../assets/sendmessage.png" @click="streamMaxApi()" class="send-msg-icon"
                        :class="{disabled:!prompt.trim()}"/>
                    </div>
                    <transition name="fade">
                        <div v-if="this.prompt.length > 1500 "
                        :style="{textAlign:'right', color:this.prompt.length> 2000 ?'red':'',}">
                        {{ this.prompt.length }} /2000 characters
                        </div>
                    </transition>
                </div>
                <img v-if="!Recording && !isRecording" src="../assets/mic.png" class="voicelogo"
                @click="startRecording" :class="{'disabled':isRecording || Recording}">
                <div v-if="Recording" class="mic-ripple-container" @click="stopRecording">
                    <div class="mic-ripple"></div>
                    <div class="mic-ripple delay1"></div>
                    <div class="mic-ripple delay2"></div>
                    <img src="../assets/mic.png" class="voicelogo mic-icon"/>
                </div>
                <img v-if="!Recording && isRecording" class="voicelogo" src="../assets/spinner.svg"
                alt="Loading..."/>

            </div>
        </div>
    </div>
    <div v-else-if="showObservationHistoryTab"
    :style="{width:isHistoryOpen?'65%':'95%',overflow:'hidden'}">

    </div>
    </div>
</div>
</template>
<script>

import HistoryPanel from './HistoryPanel.vue';
export default {
    data(){
    return {
        historyOpen:true,
        message:'',
        chatCount:0,
        chatMessages:[],
        Loading:false,
        chatHistory:[],
        optionsMenu:null,
        editingMessageIndex:null,
        editedMessage:'',
        searchQuery:"",
        queryId:null,
        isRecording:false,
        disabletext:false,
        ObservationPrompt:false,
        InteractionPrompt:false,
        RecordType:"",
        actiontype:"",
        userid:null,
        chartCanvases:[],
        timestamp:'',
        timeoutid:null,
        timer:null,
        recordObservation:false,
        compliance_flag:false,
        showALCLevelInfo:true,
        transition_observation:"",
        overlay:false,
        history:false,
        maxResponse:"",
        recentUC2message:null,
        observationdisclaimer:false,
        abortController:null,
        loading:true,
      
        splash:true,
        disablesend:false,
        speechRecognizer:null,
        webSocket:null,
        overlay:false,
        history:false,
        add_observation_prompt:false,
        counter:0,
        recommendations:[],
        agent_type:null,
        Recording:false,
        lastshowntime:null,
        isHistoryOpen:false,
        loading:true,
        is_Submitted:false,
        responseTime:null,
        tableDataMap:{},
        allChartCanvases:{},
        downloadchat:false,
        splash:true,
        isHistoryOpen:false,
        loadingveevamessage:true,
        isperson:null,

        };
    },
    components:{
        HistoryPanel,
    },
    beforeUnmount(){
        if(this.webSocket){
            this.webSocket.close();
        }
    },
    computed:{
    },
    async mounted(){
    },
    methods:{
        closeALCLevelInfo(){
            this.showALCLevelInfo=false;
        },
        openHistoryPane(tab){
            if(tab == "observationHistory"){
                this.StartNewChat()
            }
            if(tab == '' || tab == 'observationHistory'){
                this.isHistoryOpen=false;
            }else{
                this.isHistoryOpen = true;
            }

        },
        toggleHistory(){
            this.historyOpen=!this.historyOpen;
        },
        chatHistory(chathistory){
            this.chatHistory=chathistory;
        },
        async loadSessionChats(session_id){
            this.recommendations=[]
            this.closewebsocket=false
            if(this.speechRecognizer){
                this.closewebsocket=true;
                await this.stopRecording();
            }
            this.lastshowntime=null;
            this.transition_observation ="" ;
            this.observationPrompt=false;
            this.InteractionPrompt=false;
            this.disablesend=false;
            this.$store.dispatch("promptModule/setCheckExistingCallStatus",false);


        },
        StartNewChat(){
            if(this.timeoutid){
                clearTimeout(this.timeoutid);
                this.timeoutid=null;
            }
            if(this.timer){
                clearInterval(this.timer)
                this.timer=null
            }
            if(this.abortController){
                this.abortController.abort("New chat started, aborting previous request");
            }
            this.closewebsocket=false;
            if(this.speechRecognizer){
                this.closewebsocket=true;
                this.stopRecording();
            }

            this.lastshowntime=null;
            this.responseTime=null;
            this.downloadchat=false;
            this.add_observation_prompt=false;
            this.disablesend=false;
            this.disabletext=false;
            this.Loading=false;
            this.queryId=null;
            this.chatHistory=[];
            this.session_id='';
            this.prompt='',
            this.ObservationPrompt=false;
            this.InteractionPrompt=false;
           
            this.transition_observation="";
            this.actionType='';
            this.compliance_flag=false;
            this.valuestringsearch=false;
            this.observationdisclaimer=false;
            this.is_Submitted=false;
            this.isRecording=false;
            this.Recording=false;

            this.clearComplianceQuestion();
            this.$store.commit('audio/resetAudio');
            this.$store.dispatch('audio/setabortController');
            this.$store.dispatch('promptModule/setProgress',null);
            this.$store.dispatch('promptModule/highlightActiveSession',null);
            this.$store.dispatch('promptModule/setCheckExistingCallStatus',false);
            this.$store.dispatch('promptModule/setupdateExistingCall',false);
            this.$store.dispatch('promptModule/setCallId',"");
            this.$store.dispatch('promptModule/setObservationId',"");
            this.$store.dispatch('promptModule/setFollowUpEditable',true);
            this.$store.dispatch('promptModule/setCheckDoNotCallFlag',false);
            this.$store.dispatch('promptModule/obvSpinner',false);
            this.$store.dispatch('promptModule/setRecordingFollowup1',false) 
            this.$store.dispatch('promptModule/setObservationSessionChanges',false);
            this.$store.dispatch('promptModule/setShowCounter',false);
            this.$store.dispatch('promptModule/setShowRecentInteractions',false);
            this.$store.dispatch('promptModule/setSelectedCallId',"");
            this.$store.dispatch('promptModule/setSelectedCall',{});
            this.$store.dispatch('promptModule/setDiseaseStateLOVs',[]);
            this.$store.dispatch('promptModule/setNoInteractionPrompt',"");
            this.$store.dispatch('promptModule/setShowObservationHistoryTab',false);
            this.$store.dispatch('promptModule/setIsSavingObservation',false);
            this.$store.dispatch('promptModule/setDidSaveObservation',false);
            this.$store.dispatch('promptModule/setSendVeevaPrescriberID',null);
            this.$store.dispatch('promptModule/setSendVeevaHCOID',null);
        }

    }

</script>
<style scoped>

.logo-container{
    display:flex;
    flex-direction:column;
    align-items:center
}
.main-alc-container{
    position:fixed;
    right:0;
    left:92px;
    z-index:22;
}
.pointer:hover{
    cursor:pointer
}
.boehringer-head{
    font-family:'sans-serif';
}
.alc-container{
    padding:13px 17px;
    background-color:#EBEFF7;
    border-left: 3px solid #175DB0;
    text-align:left;
}
.flex{
    display:flex;
}
.space-between{
    justify-content:space-between;
}
.logoimg{
    width:80px;
    height:80px;
    opacity:1;
    margin-top:3%;
}
.mg-top-1{
    margin-top:1.5rem;
}
.logo-img{
    width:80px;
    height:80px;
    opacity:1;
    transition:transform 1s ease-in-out;
    border-radius:3em;
    filter: brightness(0) saturate(100%) invert(13%) sepia(39%) saturate(954%) hue-rotate(93deg) brightness(98%) contrast(94%) 
}
.logo{
    display:flex;
    font-size:2.5rem;
    font-weight:bold;
    position:relative;
}
.logo-span{
    display:inline-block;
    opacity:0;
}
.one-customer{
    animation:slideInLeft 2s ease forwards
}
.assist{
    animation:slideInRight 1s ease forwards;
    animation-delay:0.5s;
}
.underline{
    width:0;
    height:3px;
    background-color:#00e47c;
    margin-top:5px;
    animation:drawUnderline 1s ease forwards;
    animation-delay:1.2s;
}

#chat-main-wrapper{
    height:100%;
    display:block;
}

#chat-container-wrapper{
    height:100%;
    display:flex;
}
.overlay{
    position:absolute;
    top:0;
    right:0;
    bottom:0;
    left:0;
    background-color:grey;
    z-index:18;
    opacity:0.5
}
.chat-container{
    display:flex;
    transition:margin-left 0.3s ease;
    width:100%;
}
.chat-history-open .chat-screen{
    flex:1;
    width:65%;
}
.splashScreen{
    position:fixed;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    animation:fadeIn 0.2s;
    transition: opacity 1s ease-out,height 1s ease-out,transform 1s ease out;
}
.splashScreen.fade-out{
    opacity:0;
    transform:translate(-50%,-100%)
}
        
</style>