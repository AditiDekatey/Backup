import { createStore } from 'vuex';
import * as SpeechSDK from 'microsoft-cognitiveservices-speech-sdk';

const audioModule = {
    namespaced: true,
    state: {
        audio: null,
        currentlyPlayingIndex: null,
        previouslyPlayingIndex: null,
        audioStates:{},
        isLoading: false,
        abortController:null
    },
    mutations: {
        resetAudio(state) {
            if (state.audio) {
                state.audio.pause();
                state.audio.currentTime = 0;
            }

            Object.keys(state.audioStates).forEach(key => {
                state.audioStates[key] = {
                    isPlaying: false,
                    volume: true
                }
            });

            state.audio = null
            state.currentlyPlayingIndex = null
            state.previouslyPlayingIndex = null;
            state.isLoading = false;
        },
        setAudioObject(state, audio) {
            state.audio = audio;
        },
        setAbortController(state, abortController) {
            state.abortController = abortController;
        },
    },
    actions: {
        setAbortController({ commit, state }) {
            if (state.abortController && state.abortController.aborted) {
                state.abortController.abort();
            }
            commit("setAbortController",null)
        }
    },
}

const promptModule = {
    namespaced: true,
    state: {
        prompt: "",
        checkExistingCallStatus: false,
        checkDoNotCallFlag: false,
        updateExistingCall:false
    },
    mutations: {
        setCheckExistingCallStatus(state, status) {
            state.checkExistingCallStatus=status
        }
    },
    actions: {
        setCheckExistingCallStatus({ commit }, status) {
            commit('setCheckExistingCallStatus',status)
        }
    },
    getters: {
        checkExistingCallStatus: (state) => state.checkExistingCallStatus,
    }
}