from flask import Flask, render_template, url_for
from flask import Flask, render_template, request, redirect, url_for, session
import pickle


app = Flask(__name__)


@app.route('/')
def index():
    return render_template('form.html')


'''
@app.route('/predict', methods=['POST', 'GET'])
def predict():
    n=request.form['n']
    p=request.form['p']
    k=request.form['k']
    rain=request.form['rain']
    temp=request.form['temp']
    ph=request.form['ph']
    humid=request.form['humid']
    
    

'''
